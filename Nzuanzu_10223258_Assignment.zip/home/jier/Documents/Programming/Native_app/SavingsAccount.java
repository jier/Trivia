
public class SavingsAccount {
	private int balance;

	public SavingsAccount() {
		balance = 0;
	}

	public SavingsAccount(int initialBalance) {
		balance = initialBalance;
	}

	public void greet() {
		System.out.println("\n****************************************");
		System.out.println("Welcome to the Wakanda Saving account.");
		System.out.println("Let see how much you have saved up so far.");
		System.out.println("*******************************************\n");
	}

	public void showBalance() {
		System.out.println("Your balance is now: " + balance);
	}


	public void deposit(int howMuch) {
		if (howMuch > 0) {
			balance = balance + howMuch;
		}else {
			System.err.println("The amount is negative");
		}
	}

	public void withdraw(int howMuch) {
		if (howMuch > 0) {
			balance = balance - howMuch;
		}else {
			System.err.println("The amount is negative");
		}
	}
}