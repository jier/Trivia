public class BRTest {

	private int calls, succesfulCalls, totalReturned;
	private int[] excepCounts;


	public void callIt() {
		calls++;
		try {
			totalReturned = totalReturned + BadRandom.randVal();
			succesfulCalls++;
		} 
		catch (ArithmeticException e) {
			System.err.println("ArithmetichException caught " + e.getMessage());
			excepCounts[0]++;
		}
		catch (NullPointerException e) {
			System.err.println("NUllPointerException caught " + e.getMessage());
			excepCounts[1]++;
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("ArrayIndexOutOfBoundsException caught " + e.getMessage());
			excepCounts[2]++;
		}
		catch (ClassCastException e) {
			System.err.println("ClassCastException caught " + e.getMessage());
			excepCounts[3]++;
		}
		catch (NegativeArraySizeException e) {
			System.err.println("NegativeArraySizeException caught " + e.getMessage());
			excepCounts[4]++;
		}
	}

	public void resetCounts() {
		calls = succesfulCalls =totalReturned = 0;
		excepCounts = new int[5];
	}

	public void nRandInts(int n) {
		for (int i = 0; i < n; i++) {
			callIt();
		}
	}

	public void writeData() {
		System.out.println("\n*************************************************************");
		System.out.println("The number of calls " + calls);
		System.out.println("The number of successfull calls " + succesfulCalls);
		System.out.println("The total of the values returned by the successfull calls "+ totalReturned);
		System.out.println("ArithmetichException " + (float)excepCounts[0] / calls * 100 + " %");
		System.out.println("NUllPointerException " + (float)excepCounts[1] / calls * 100+ " %");
		System.out.println("ArrayIndexOutOfBoundsException " + (float)excepCounts[2] / calls * 100+ " %");
		System.out.println("ClassCastException" + (float)excepCounts[3] / calls * 100+ " %");
		System.out.println("NegativeArraySizeException " + (float)excepCounts[4] / calls * 100+ " %");
		System.out.println("Successfull calls " + (float) succesfulCalls/calls * 100 + " %");
		System.out.println("****************************************************************\n ");
	}

	public static void main(String[] args) {
		BRTest test = new BRTest();
		test.resetCounts();
		test.nRandInts(100);
		test.writeData();
	}	

}