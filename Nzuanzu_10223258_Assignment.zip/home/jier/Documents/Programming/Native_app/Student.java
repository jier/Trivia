/* Need to import java.io package to use the BufferedReader and
   InputStreamReader. 
 */

import java.io.*;
import java.lang.*;
public class Student {

	private static BufferedReader stdIn = new BufferedReader(new
			InputStreamReader(System.in));

	private String name;
	private int age;

	public Student () {
		name = "";
		age = 0;
	}

	public void readName () throws IOException {
		System.out.print("Input your name: ");
		name = stdIn.readLine();
	}
	
	public void readAge () throws IOException, NumberFormatException {
		
		String in = "" ;
		int i = 0;
		while (i <= 150) {
			System.out.print("Input your age: ");
			try {
				in  = stdIn.readLine();	
			} catch (IOException e) {
				System.err.println("This is an input Exception " + e.getMessage());
				System.exit(1);
			}
			
			try {
				age = Integer.parseInt(in);	
			} catch (NumberFormatException num) {
				age = -1;
				System.err.println("This is not a valid entry for an age " + num.getMessage());
			}
			if (i == age) {
				break;
			} else {
				i++;
				continue;
			}
		}
	}

	public void printName () {
		System.out.println("Name: " + name);
		
	}

	public void printAge () {
		System.out.println("Age: " + age);
	}

	public static void main (String[] args) throws IOException {
		Student me = new Student();
		me.readName();
		me.readAge();
		me.printName();
		me.printAge();

	}
}



