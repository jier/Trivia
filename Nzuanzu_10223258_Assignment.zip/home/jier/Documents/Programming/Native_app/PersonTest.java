class Person {

   // Properties of the class...
   private String name;
   public int    age;
   private String profession;
	
   // Constructor of the class...
   public Person(String aName, int anAge, String aprofession) {
		name = aName;
		age  = anAge;
		profession = aprofession;
   }

   // Methods of the class...
   public void talk() {
		System.out.println("Hi, my name's " + name);
		System.out.println("and my age is " + age);
		System.out.println("and I am a " + profession);
		System.out.println();
		commentAboutAge();
		}
   public void commentAboutAge() {
		if (age < 5) {
		 System.out.println("baby");
		}
		if (age == 5) {
		 System.out.println("time to start school");
		}
		if (age > 60) {
		System.out.println("Old person");
		}
	}
	
	public void growOlder() {
		int new_age = age + 1;
		System.out.println("I am now " + new_age + " older"); 
	}
	
	public void giveKnighthood() {
		System.out.println("Sir " + name);
	}
	
	public void growOlderBy(int years) {
		int new_age = age + years;
		System.out.println(name +" ,you have grown older by " + years +" years "+ new_age);
	}
}
class PersonTest {

   // The main method is the point of entry into the program...
   public static void main(String[] args) {

		//Person ls = new Person("Luke Skywalker", 34,"Jedi");
		//Person wp = new Person("Winston Peters", 48, "Teacher");
		Person ls = new Person();
		Person wp = new Person();
		ls.talk();
		wp.talk();
		wp.growOlder();		
		wp.giveKnighthood();
		System.out.println("My age is " + ls.age + " and Luke skywalker I am");
		ls.growOlderBy(10);
	}

}

